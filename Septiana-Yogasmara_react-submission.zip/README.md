# This project is created for finishing a react course.

## Main Feature :

- Create notes
- View notes
- Delete Notes

## Optional Features :

- Search Notes
- Max char for title
- Notes archive

Created by : Yogasmara
